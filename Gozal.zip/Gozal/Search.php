<header class="page-header">
  
  
<h1 class="page-title"><?php printf( __( 'Search Results for: %s', 'twentyfifteen' ), get_search_query() ); ?></h1>
  
  
</header>
  
  
<!-- .page-header -->