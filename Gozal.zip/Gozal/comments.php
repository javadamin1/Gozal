<?php

/**
 * Comments template
 *
 * @package Gozal
 */

?>