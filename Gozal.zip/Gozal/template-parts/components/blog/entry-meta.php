<?php
/**
 * Template for entry meta
 * 
 * @package Gozal
 * 
 */
?>
<div class="entry-meta mb-3">
    <?php gozal_posted_on();gozal_posted_by() ?>
</div>